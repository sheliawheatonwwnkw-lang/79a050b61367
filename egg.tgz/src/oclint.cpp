// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("oclint"); }
int main(){
  announce();
  return lionss_run_workload("oclint");
}
