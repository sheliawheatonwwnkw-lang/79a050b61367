// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("fixme scan\n", stdout);
  return lionss_run_workload("fixme-scan");
}
