// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("unused includes"); }
int main(){
  announce();
  return lionss_run_workload("unused-includes");
}
