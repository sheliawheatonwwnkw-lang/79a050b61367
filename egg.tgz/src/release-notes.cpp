// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("release notes\n", stdout);
  return lionss_run_workload("release-notes");
}
